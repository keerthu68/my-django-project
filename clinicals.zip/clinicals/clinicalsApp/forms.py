from django import forms
from clinicalsApp.models import ClinicalData,Patient

class PatientForm(forms.ModelForm):
    class Meta:
        '''
        The Meta class specifies which model the form should be based on. Here, it tells Django that this form corresponds to the Patient model.
       This means Django will automatically generate form fields based on the fields in the Patient model.
       Selecting Fields (fields = '__all__')
        The fields attribute controls which model fields should be included in the form.
        Setting fields = '__all__' means all fields from the Patient model will be included in the form.
       '''
        model = Patient
        fields = '__all__'

class ClinicalDataForm(forms.ModelForm):
    class Meta:
        model=ClinicalData
        fields = '__all__'
