from django.apps import AppConfig


class ClinicalsappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'clinicalsApp'
